/**
 * Created by jeffrey on 3/23/2014.
 */
public class verificationException extends Exception{
    public verificationException() {super();}
    public verificationException(String message){super(message);}
}
